Microvellum Construction Recipe Maps (Generated)

Files
- mv_construction_recipes_ikea_like.ts
  Keyword-inferred construction recipes for the IKEA-like subset XML.
- mv_construction_recipes_full.ts
  Keyword-inferred construction recipes for the full library XML (includes accessories like panels/rails/trim).
- mv_construction_recipes_ikea_like_review.csv
- mv_construction_recipes_full_review.csv
  Quick review sheets (productName -> category/frontType/corner/appliance/notes) for manual tweaking.

How to use in your 3D planner (Lovable/React)
1) Import the recipe map (IKEA-like recommended first):
   import { MV_CONSTRUCTION_RECIPES_IKEA_LIKE, getConstructionRecipe } from "./mv_construction_recipes_ikea_like";

2) When a user selects a cabinet productName, fetch:
   const recipe = getConstructionRecipe(productName);

3) Build geometry from recipe:
   - Carcass: 18mm gables/panels, 3mm back recessed 18mm
   - Toe kick: 135mm high, 50mm setback, 16mm kickboard, legs rendered as 4 posts
   - Fronts:
       DOORS: full overlay, 2mm gaps, 1 or 2 doors
       DRAWERS: face heights from ratios (default 5-drawer ratios provided)
       COMBO: drawers on top + doors below with a divider panel
       SINK: optional 80mm false front + doors
       CORNERS: use corner.render hint to choose L-arm vs blind extension vs 45° diagonal
       OPEN: shelves only
       APPLIANCE_OPENING: render opening box, optional top drawer
   - Benchtop: Base cabinets only (enabled=true), 20mm thickness, 20mm front overhang

4) Keep cabinet resizing:
   Use the recipe only to decide part layout; the cabinet width/height/depth inputs still drive dimensions.

Notes
- This is a best-effort inference from product names; anything odd can be corrected by editing the CSV, then regenerating the TS map (or manual edits).
