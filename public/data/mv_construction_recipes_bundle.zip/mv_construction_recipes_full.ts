    /* Auto-generated cabinet construction recipe map.
       Source: Microvellum import XML product list.
       Notes:
       - Recipes are inferred from productName keywords and Ben's construction reference:
         18mm gables/panels, 3mm back recessed 18mm, 16mm kickboard, full overlay doors (2mm gaps), adjustable legs.
       - This is meant for rendering + default prompt/hardware mapping, not final MV subassemblies.
    */

    export type RecipeCategory =
      | "BASE"
      | "UPPER"
      | "TALL"
      | "SUSPENDED"
      | "PANEL"
      | "FILLER"
      | "TOEKICK"
      | "TRIM"
      | "TEMPLATE"
      | "MISC";

    export type Fronts =
      | {
          type: "DOORS";
          doorCount: number;
          overlay: "FULL_OVERLAY";
          revealGapMm: number;
          glassDoor?: boolean;
        }
      | {
          type: "DRAWERS";
          drawerCount: number;
          revealGapMm: number;
          ratios?: number[] | null;
          drawerBays?: number | null;
        }
      | {
          type: "COMBO";
          topDrawers: number;
          bottomDoors: number;
          dividerThicknessMm: number;
          revealGapMm: number;
        }
      | {
          type: "SINK";
          doorCount: number;
          hasFalseFront: boolean;
          falseFrontHeightMm: number;
          revealGapMm: number;
        }
      | {
          type: "WASTEBIN";
          hasTopDrawer: boolean;
          pulloutFronts: number;
          revealGapMm: number;
        }
      | {
          type: "APPLIANCE_OPENING";
          appliance: "MICROWAVE" | "OVEN" | "RANGEHOOD" | "FRIDGE" | "APPLIANCE";
          hasTopDrawer: boolean;
          hasDoors: boolean;
          doorCount: number;
          revealGapMm: number;
        }
      | {
          type: "OPEN";
          shelfCount: number;
        };

    export type Corner =
      | {
          style: "L_SHAPE" | "BLIND" | "DIAGONAL" | "CORNER_PANTRY" | "ANGLE";
          render: "L_ARMS" | "BLIND_EXTENSION" | "DIAGONAL_FRONT_45" | "CORNER_PANTRY" | "ANGLE_FRONT";
        }
      | null;

    export type ConstructionRecipe =
      | {
          productName: string;
          category: RecipeCategory;
          carcass: {
            gableThicknessMm: number;
            panelThicknessMm: number;
            backThicknessMm: number;
            backRecessMm: number;
            hasTopPanel: boolean;
            hasBottomPanel: boolean;
            hasBackPanel: boolean;
          };
          toeKick: {
            enabled: boolean;
            heightMm?: number;
            setbackMm?: number;
            kickboardThicknessMm?: number;
            legs?: boolean;
            legsCount?: number;
          };
          shelves: {
            adjustable: boolean;
            count: number;
            pigeonHoles?: boolean;
            wineRack?: boolean;
          };
          fronts: Fronts;
          corner: Corner;
          special: Record<string, any>;
          hardwareDefaults: {
            hingeBrand: string;
            hingeType: string;
            drawerSlideType: string;
            drawerSystem: string;
            doorMechanism?: "Sliding" | "Folding";
          };
          renderHints: {
            doorStyle: "slab" | "shaker";
            showHandles: boolean;
          };
          benchtop: {
            enabled: boolean;
            thicknessMm?: number;
            overhangFrontMm?: number;
            overhangSideMm?: number;
          };
        }
      | {
          productName: string;
          category: "PANEL" | "FILLER" | "TOEKICK" | "TRIM";
          accessory: {
            type: "PANEL" | "FILLER" | "TOEKICK" | "TRIM";
            thicknessMm: number;
            render: "RECT_EXTRUSION";
          };
          renderHints: {
            showHandles: boolean;
          };
        };

    export const MV_CONSTRUCTION_RECIPES_FULL: Record<string, ConstructionRecipe> = {
  "1 Drawer Suspended Cabinet": {
    "productName": "1 Drawer Suspended Cabinet",
    "category": "SUSPENDED",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "DRAWERS",
      "drawerCount": 1,
      "revealGapMm": 2,
      "ratios": null,
      "drawerBays": null
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "2 Drawer Suspended Cabinet": {
    "productName": "2 Drawer Suspended Cabinet",
    "category": "SUSPENDED",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "DRAWERS",
      "drawerCount": 2,
      "revealGapMm": 2,
      "ratios": null,
      "drawerBays": null
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Any Angle Spacer": {
    "productName": "Any Angle Spacer",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Any Angle Toe Kick Base": {
    "productName": "Any Angle Toe Kick Base",
    "category": "TOEKICK",
    "accessory": {
      "type": "TOEKICK",
      "thicknessMm": 16,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Applied Panel": {
    "productName": "Applied Panel",
    "category": "PANEL",
    "accessory": {
      "type": "PANEL",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Backsplash": {
    "productName": "Backsplash",
    "category": "TRIM",
    "accessory": {
      "type": "TRIM",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Bar Die Wall": {
    "productName": "Bar Die Wall",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Bar Stools": {
    "productName": "Bar Stools",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Base 1 Door": {
    "productName": "Base 1 Door",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 1 Door 1 Drawer": {
    "productName": "Base 1 Door 1 Drawer",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "COMBO",
      "topDrawers": 1,
      "bottomDoors": 1,
      "dividerThicknessMm": 18,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 1 Door 1 Drawer Blind Corner": {
    "productName": "Base 1 Door 1 Drawer Blind Corner",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "COMBO",
      "topDrawers": 1,
      "bottomDoors": 1,
      "dividerThicknessMm": 18,
      "revealGapMm": 2
    },
    "corner": {
      "style": "BLIND",
      "render": "BLIND_EXTENSION"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 1 Door No Bottom": {
    "productName": "Base 1 Door No Bottom",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": false,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 1 Door Sink": {
    "productName": "Base 1 Door Sink",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "SINK",
      "doorCount": 1,
      "falseFrontHeightMm": 80,
      "hasFalseFront": false,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "isSink": true,
      "hasFalseFront": false
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 1 Door Sink With False Front": {
    "productName": "Base 1 Door Sink With False Front",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "SINK",
      "doorCount": 1,
      "falseFrontHeightMm": 80,
      "hasFalseFront": true,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "isSink": true,
      "hasFalseFront": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 1 Drawer": {
    "productName": "Base 1 Drawer",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "DRAWERS",
      "drawerCount": 1,
      "revealGapMm": 2,
      "ratios": null,
      "drawerBays": null
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 1 Drawer Microwave": {
    "productName": "Base 1 Drawer Microwave",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "APPLIANCE_OPENING",
      "appliance": "MICROWAVE",
      "hasTopDrawer": true,
      "hasDoors": false,
      "doorCount": 0,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "appliance": "MICROWAVE"
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 1 Drawer Waste Bin": {
    "productName": "Base 1 Drawer Waste Bin",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "WASTEBIN",
      "hasTopDrawer": false,
      "pulloutFronts": 1,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "wasteBin": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 1 Drawer Waste Bin With Top Drawer": {
    "productName": "Base 1 Drawer Waste Bin With Top Drawer",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "WASTEBIN",
      "hasTopDrawer": true,
      "pulloutFronts": 1,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "wasteBin": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 2 Bay Drawer": {
    "productName": "Base 2 Bay Drawer",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "DRAWERS",
      "drawerCount": 3,
      "revealGapMm": 2,
      "ratios": [
        0.25,
        0.33,
        0.42
      ],
      "drawerBays": 2
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 2 Door": {
    "productName": "Base 2 Door",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 2,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 2 Door 1 Drawer": {
    "productName": "Base 2 Door 1 Drawer",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "COMBO",
      "topDrawers": 1,
      "bottomDoors": 2,
      "dividerThicknessMm": 18,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 2 Door 1 Drawer Blind Corner": {
    "productName": "Base 2 Door 1 Drawer Blind Corner",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "COMBO",
      "topDrawers": 1,
      "bottomDoors": 2,
      "dividerThicknessMm": 18,
      "revealGapMm": 2
    },
    "corner": {
      "style": "BLIND",
      "render": "BLIND_EXTENSION"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 2 Door 2 Drawer": {
    "productName": "Base 2 Door 2 Drawer",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "COMBO",
      "topDrawers": 2,
      "bottomDoors": 2,
      "dividerThicknessMm": 18,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 2 Door 4 Drawer Cabinet": {
    "productName": "Base 2 Door 4 Drawer Cabinet",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "COMBO",
      "topDrawers": 4,
      "bottomDoors": 2,
      "dividerThicknessMm": 18,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 2 Door ADA Sink": {
    "productName": "Base 2 Door ADA Sink",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "SINK",
      "doorCount": 2,
      "falseFrontHeightMm": 80,
      "hasFalseFront": false,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "isSink": true,
      "hasFalseFront": false
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 2 Door ADA Sink With False Front": {
    "productName": "Base 2 Door ADA Sink With False Front",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "SINK",
      "doorCount": 2,
      "falseFrontHeightMm": 80,
      "hasFalseFront": true,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "isSink": true,
      "hasFalseFront": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 2 Door No Bottom": {
    "productName": "Base 2 Door No Bottom",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": false,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 2,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 2 Door Sink": {
    "productName": "Base 2 Door Sink",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "SINK",
      "doorCount": 2,
      "falseFrontHeightMm": 80,
      "hasFalseFront": false,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "isSink": true,
      "hasFalseFront": false
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 2 Door Sink With False Front": {
    "productName": "Base 2 Door Sink With False Front",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "SINK",
      "doorCount": 2,
      "falseFrontHeightMm": 80,
      "hasFalseFront": true,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "isSink": true,
      "hasFalseFront": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 2 Doors Middle 4 Drawer Cabinet": {
    "productName": "Base 2 Doors Middle 4 Drawer Cabinet",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "COMBO",
      "topDrawers": 4,
      "bottomDoors": 2,
      "dividerThicknessMm": 18,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 2 Drawer": {
    "productName": "Base 2 Drawer",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "DRAWERS",
      "drawerCount": 2,
      "revealGapMm": 2,
      "ratios": null,
      "drawerBays": null
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 2 Drawer Waste Bin": {
    "productName": "Base 2 Drawer Waste Bin",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "WASTEBIN",
      "hasTopDrawer": false,
      "pulloutFronts": 1,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "wasteBin": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 3 Door": {
    "productName": "Base 3 Door",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 3,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 3 Drawer": {
    "productName": "Base 3 Drawer",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "DRAWERS",
      "drawerCount": 3,
      "revealGapMm": 2,
      "ratios": [
        0.25,
        0.33,
        0.42
      ],
      "drawerBays": null
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 3 Drawer 2 Door Cabinet": {
    "productName": "Base 3 Drawer 2 Door Cabinet",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "COMBO",
      "topDrawers": 3,
      "bottomDoors": 2,
      "dividerThicknessMm": 18,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 3 Drawer Split Top Drawer": {
    "productName": "Base 3 Drawer Split Top Drawer",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "DRAWERS",
      "drawerCount": 3,
      "revealGapMm": 2,
      "ratios": [
        0.25,
        0.33,
        0.42
      ],
      "drawerBays": null
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 4 Drawer": {
    "productName": "Base 4 Drawer",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "DRAWERS",
      "drawerCount": 4,
      "revealGapMm": 2,
      "ratios": [
        0.18,
        0.22,
        0.28,
        0.32
      ],
      "drawerBays": null
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 4 Drawer Split Top Drawer": {
    "productName": "Base 4 Drawer Split Top Drawer",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "DRAWERS",
      "drawerCount": 4,
      "revealGapMm": 2,
      "ratios": [
        0.18,
        0.22,
        0.28,
        0.32
      ],
      "drawerBays": null
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 5 Drawer": {
    "productName": "Base 5 Drawer",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "DRAWERS",
      "drawerCount": 5,
      "revealGapMm": 2,
      "ratios": [
        0.14,
        0.18,
        0.22,
        0.22,
        0.24
      ],
      "drawerBays": null
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 6 Drawer": {
    "productName": "Base 6 Drawer",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "DRAWERS",
      "drawerCount": 6,
      "revealGapMm": 2,
      "ratios": null,
      "drawerBays": null
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base 7 Drawer": {
    "productName": "Base 7 Drawer",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "DRAWERS",
      "drawerCount": 7,
      "revealGapMm": 2,
      "ratios": null,
      "drawerBays": null
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Any Angle Cabinet": {
    "productName": "Base Any Angle Cabinet",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Applied Back Panel": {
    "productName": "Base Applied Back Panel",
    "category": "PANEL",
    "accessory": {
      "type": "PANEL",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Base Applied Panel": {
    "productName": "Base Applied Panel",
    "category": "PANEL",
    "accessory": {
      "type": "PANEL",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Base Blind Corner": {
    "productName": "Base Blind Corner",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": {
      "style": "BLIND",
      "render": "BLIND_EXTENSION"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Corner Diagonal Cabinet": {
    "productName": "Base Corner Diagonal Cabinet",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": {
      "style": "DIAGONAL",
      "render": "DIAGONAL_FRONT_45"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Corner Filler With Cleats": {
    "productName": "Base Corner Filler With Cleats",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Base Corner Open Cabinet": {
    "productName": "Base Corner Open Cabinet",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": {
      "style": "L_SHAPE",
      "render": "L_ARMS"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Corner Open Diagonal Cabinet": {
    "productName": "Base Corner Open Diagonal Cabinet",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": {
      "style": "DIAGONAL",
      "render": "DIAGONAL_FRONT_45"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Diagonal Angle Cabinet": {
    "productName": "Base Diagonal Angle Cabinet",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Drawer Sink With False Front": {
    "productName": "Base Drawer Sink With False Front",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "SINK",
      "doorCount": 2,
      "falseFrontHeightMm": 80,
      "hasFalseFront": true,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "isSink": true,
      "hasFalseFront": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Folding Door Cabinet": {
    "productName": "Base Folding Door Cabinet",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim",
      "doorMechanism": "Folding"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Island Box End": {
    "productName": "Base Island Box End",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Open": {
    "productName": "Base Open",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Open 1 Drawer": {
    "productName": "Base Open 1 Drawer",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Open 2 Drawer": {
    "productName": "Base Open 2 Drawer",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Open Blind Corner": {
    "productName": "Base Open Blind Corner",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": {
      "style": "BLIND",
      "render": "BLIND_EXTENSION"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Open Diagonal Angle Cabinet": {
    "productName": "Base Open Diagonal Angle Cabinet",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Open End Cabinet": {
    "productName": "Base Open End Cabinet",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Open Pigeon Holes": {
    "productName": "Base Open Pigeon Holes",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": false,
      "count": 0,
      "pigeonHoles": true
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {
      "pigeonHoles": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Opening with End Panels": {
    "productName": "Base Opening with End Panels",
    "category": "PANEL",
    "accessory": {
      "type": "PANEL",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Base Pullout": {
    "productName": "Base Pullout",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Return Filler": {
    "productName": "Base Return Filler",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Base Scribe Filler": {
    "productName": "Base Scribe Filler",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Base Scribe Filler With Cleats": {
    "productName": "Base Scribe Filler With Cleats",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Base Sliding Door Cabinet": {
    "productName": "Base Sliding Door Cabinet",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim",
      "doorMechanism": "Sliding"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Spacer Corner Drawers": {
    "productName": "Base Spacer Corner Drawers",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Base Starter": {
    "productName": "Base Starter",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": null,
    "special": {
      "starter": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Transition Angle Cabinet": {
    "productName": "Base Transition Angle Cabinet",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Under Counter Oven": {
    "productName": "Base Under Counter Oven",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "APPLIANCE_OPENING",
      "appliance": "OVEN",
      "hasTopDrawer": false,
      "hasDoors": false,
      "doorCount": 0,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "appliance": "OVEN"
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Base Winerack": {
    "productName": "Base Winerack",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": false,
      "count": 0,
      "wineRack": true
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {
      "wineRack": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Box End": {
    "productName": "Box End",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Bracket Array": {
    "productName": "Bracket Array",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Bracket Single": {
    "productName": "Bracket Single",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Cabinet Faces Only": {
    "productName": "Cabinet Faces Only",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Corner Filler With Cleats": {
    "productName": "Corner Filler With Cleats",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Corner Toe Kick Base": {
    "productName": "Corner Toe Kick Base",
    "category": "TOEKICK",
    "accessory": {
      "type": "TOEKICK",
      "thicknessMm": 16,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Counter Height 1 Door": {
    "productName": "Counter Height 1 Door",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Counter Height 2 Door": {
    "productName": "Counter Height 2 Door",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 2,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Counter Height Appliance Cabinet": {
    "productName": "Counter Height Appliance Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Counter Height Diagonal Corner Appliance Cabinet": {
    "productName": "Counter Height Diagonal Corner Appliance Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": {
      "style": "DIAGONAL",
      "render": "DIAGONAL_FRONT_45"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Counter Height Diagonal Corner Cabinet": {
    "productName": "Counter Height Diagonal Corner Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": {
      "style": "DIAGONAL",
      "render": "DIAGONAL_FRONT_45"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Counter Height Hutch": {
    "productName": "Counter Height Hutch",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Counter Height Hutch With Pigeon Holes": {
    "productName": "Counter Height Hutch With Pigeon Holes",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0,
      "pigeonHoles": true
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {
      "pigeonHoles": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Counter Height Starter": {
    "productName": "Counter Height Starter",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {
      "starter": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Counter Height With Tambour Door": {
    "productName": "Counter Height With Tambour Door",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Countertop With Substrate": {
    "productName": "Countertop With Substrate",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Countertop With Waterfall Ends": {
    "productName": "Countertop With Waterfall Ends",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Curved Die Wall": {
    "productName": "Curved Die Wall",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Curved Part": {
    "productName": "Curved Part",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Diagonal Toe Kick Base": {
    "productName": "Diagonal Toe Kick Base",
    "category": "TOEKICK",
    "accessory": {
      "type": "TOEKICK",
      "thicknessMm": 16,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Die Wall Stud": {
    "productName": "Die Wall Stud",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Die Wall w Skins": {
    "productName": "Die Wall w Skins",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Die Wall w Studs Only": {
    "productName": "Die Wall w Studs Only",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Dishwasher": {
    "productName": "Dishwasher",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Ellipse": {
    "productName": "Ellipse",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Extruded Base Cabinet": {
    "productName": "Extruded Base Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Extruded Crown": {
    "productName": "Extruded Crown",
    "category": "TRIM",
    "accessory": {
      "type": "TRIM",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Extruded Master Cabinet": {
    "productName": "Extruded Master Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Extruded Master Countertop": {
    "productName": "Extruded Master Countertop",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Extruded Master Part": {
    "productName": "Extruded Master Part",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Extruded Part Collection": {
    "productName": "Extruded Part Collection",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Extruded Part Horizontal": {
    "productName": "Extruded Part Horizontal",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Extruded Part Vertical": {
    "productName": "Extruded Part Vertical",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Extruded Toe Kick Base": {
    "productName": "Extruded Toe Kick Base",
    "category": "TOEKICK",
    "accessory": {
      "type": "TOEKICK",
      "thicknessMm": 16,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Extruded Upper Cabinet": {
    "productName": "Extruded Upper Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Filleted Panel": {
    "productName": "Filleted Panel",
    "category": "PANEL",
    "accessory": {
      "type": "PANEL",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Fridge": {
    "productName": "Fridge",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "APPLIANCE_OPENING",
      "appliance": "FRIDGE",
      "hasTopDrawer": false,
      "hasDoors": false,
      "doorCount": 0,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "appliance": "FRIDGE"
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Hawa-Concepta Pocket Doors": {
    "productName": "Hawa-Concepta Pocket Doors",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Horizontal Designer Suspended Cabinet": {
    "productName": "Horizontal Designer Suspended Cabinet",
    "category": "SUSPENDED",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Integrated Dishwasher": {
    "productName": "Integrated Dishwasher",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Liftup Door Cabinet": {
    "productName": "Liftup Door Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master 2 Bay Horizontal Cabinet": {
    "productName": "Master 2 Bay Horizontal Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Angle End Cabinet": {
    "productName": "Master Angle End Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Angled Ends Cabinet": {
    "productName": "Master Angled Ends Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Any Angle Cabinet": {
    "productName": "Master Any Angle Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Any Angle Spacer": {
    "productName": "Master Any Angle Spacer",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Master Appliance Cabinet": {
    "productName": "Master Appliance Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Applied Back Panel": {
    "productName": "Master Applied Back Panel",
    "category": "PANEL",
    "accessory": {
      "type": "PANEL",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Master Blind Corner Cabinet": {
    "productName": "Master Blind Corner Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": {
      "style": "BLIND",
      "render": "BLIND_EXTENSION"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Cabinet": {
    "productName": "Master Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Corner Cabinet": {
    "productName": "Master Corner Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": {
      "style": "L_SHAPE",
      "render": "L_ARMS"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Corner Open Cabinet": {
    "productName": "Master Corner Open Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": {
      "style": "L_SHAPE",
      "render": "L_ARMS"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Corner Vertical Designer Cabinet": {
    "productName": "Master Corner Vertical Designer Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": {
      "style": "L_SHAPE",
      "render": "L_ARMS"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Diagonal Angle Cabinet": {
    "productName": "Master Diagonal Angle Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Diagonal Vertical Designer Cabinet": {
    "productName": "Master Diagonal Vertical Designer Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Die Wall": {
    "productName": "Master Die Wall",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Double Sided Cabinet": {
    "productName": "Master Double Sided Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Enclosed Appliance Cabinet": {
    "productName": "Master Enclosed Appliance Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Horizontal Designer Cabinet": {
    "productName": "Master Horizontal Designer Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Open Cabinet": {
    "productName": "Master Open Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Open Corner End Cabinet": {
    "productName": "Master Open Corner End Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": {
      "style": "L_SHAPE",
      "render": "L_ARMS"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Split Cabinet": {
    "productName": "Master Split Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Split Corner Cabinet": {
    "productName": "Master Split Corner Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": {
      "style": "L_SHAPE",
      "render": "L_ARMS"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Split Height Designer Cabinet": {
    "productName": "Master Split Height Designer Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Transition Angle Cabinet": {
    "productName": "Master Transition Angle Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Master Under Stair Cabinet": {
    "productName": "Master Under Stair Cabinet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Misc Panel": {
    "productName": "Misc Panel",
    "category": "PANEL",
    "accessory": {
      "type": "PANEL",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Mitered End Panel": {
    "productName": "Mitered End Panel",
    "category": "PANEL",
    "accessory": {
      "type": "PANEL",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Mitered Shelf": {
    "productName": "Mitered Shelf",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Open Corner Toe Kick Base": {
    "productName": "Open Corner Toe Kick Base",
    "category": "TOEKICK",
    "accessory": {
      "type": "TOEKICK",
      "thicknessMm": 16,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Open Horizontal Designer Suspended Cabinet": {
    "productName": "Open Horizontal Designer Suspended Cabinet",
    "category": "SUSPENDED",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Open Suspended Cabinet": {
    "productName": "Open Suspended Cabinet",
    "category": "SUSPENDED",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Pelmet": {
    "productName": "Pelmet",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Perforated Panel": {
    "productName": "Perforated Panel",
    "category": "PANEL",
    "accessory": {
      "type": "PANEL",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Pricing Prime Cost Product": {
    "productName": "Pricing Prime Cost Product",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Radius Stud Wall": {
    "productName": "Radius Stud Wall",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Return Filler": {
    "productName": "Return Filler",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Round Top": {
    "productName": "Round Top",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Scribe Filler": {
    "productName": "Scribe Filler",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Scribe Filler With Cleats": {
    "productName": "Scribe Filler With Cleats",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Slatwall": {
    "productName": "Slatwall",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Soffit": {
    "productName": "Soffit",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Starter Panel": {
    "productName": "Starter Panel",
    "category": "PANEL",
    "accessory": {
      "type": "PANEL",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Straight Die Wall": {
    "productName": "Straight Die Wall",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Straight Stud Wall": {
    "productName": "Straight Stud Wall",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Straight Tapered Die Wall": {
    "productName": "Straight Tapered Die Wall",
    "category": "MISC",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall 1 Door": {
    "productName": "Tall 1 Door",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall 1 Door Broom Cabinet": {
    "productName": "Tall 1 Door Broom Cabinet",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall 1 Door No Bottom": {
    "productName": "Tall 1 Door No Bottom",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": false,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall 1 Door With Fixed Shelf": {
    "productName": "Tall 1 Door With Fixed Shelf",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": false,
      "count": 1
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall 1 Door With Inner Drawers": {
    "productName": "Tall 1 Door With Inner Drawers",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {
      "innerDrawers": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall 2 Door": {
    "productName": "Tall 2 Door",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 2,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall 2 Door Angled Back": {
    "productName": "Tall 2 Door Angled Back",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 2,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall 2 Door Broom Cabinet": {
    "productName": "Tall 2 Door Broom Cabinet",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 2,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall 2 Door No Bottom": {
    "productName": "Tall 2 Door No Bottom",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": false,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 2,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall 2 Door Pantry": {
    "productName": "Tall 2 Door Pantry",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 2,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall 2 Door With Fixed Shelf": {
    "productName": "Tall 2 Door With Fixed Shelf",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": false,
      "count": 1
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 2,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall 2 Door With Inner Drawers": {
    "productName": "Tall 2 Door With Inner Drawers",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 2,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {
      "innerDrawers": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall 3 Door": {
    "productName": "Tall 3 Door",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 3,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Any Angle Cabinet": {
    "productName": "Tall Any Angle Cabinet",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 4
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Applied Back Panel": {
    "productName": "Tall Applied Back Panel",
    "category": "PANEL",
    "accessory": {
      "type": "PANEL",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Tall Applied Panel": {
    "productName": "Tall Applied Panel",
    "category": "PANEL",
    "accessory": {
      "type": "PANEL",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Tall Blind Corner": {
    "productName": "Tall Blind Corner",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 4
    },
    "corner": {
      "style": "BLIND",
      "render": "BLIND_EXTENSION"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Corner Diagonal Cabinet": {
    "productName": "Tall Corner Diagonal Cabinet",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 4
    },
    "corner": {
      "style": "DIAGONAL",
      "render": "DIAGONAL_FRONT_45"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Corner Filler With Cleats": {
    "productName": "Tall Corner Filler With Cleats",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Tall Corner Open Cabinet": {
    "productName": "Tall Corner Open Cabinet",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 4
    },
    "corner": {
      "style": "L_SHAPE",
      "render": "L_ARMS"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Corner Open Diagonal Cabinet": {
    "productName": "Tall Corner Open Diagonal Cabinet",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 4
    },
    "corner": {
      "style": "DIAGONAL",
      "render": "DIAGONAL_FRONT_45"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Corner Pantry Cabinet": {
    "productName": "Tall Corner Pantry Cabinet",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 4
    },
    "corner": {
      "style": "CORNER_PANTRY",
      "render": "CORNER_PANTRY"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Diagonal Angle Cabinet": {
    "productName": "Tall Diagonal Angle Cabinet",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 4
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Folding Door Cabinet": {
    "productName": "Tall Folding Door Cabinet",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim",
      "doorMechanism": "Folding"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Fridge Cabinet": {
    "productName": "Tall Fridge Cabinet",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "APPLIANCE_OPENING",
      "appliance": "FRIDGE",
      "hasTopDrawer": false,
      "hasDoors": false,
      "doorCount": 0,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "appliance": "FRIDGE"
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Open": {
    "productName": "Tall Open",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 4
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Open Blind Corner": {
    "productName": "Tall Open Blind Corner",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 4
    },
    "corner": {
      "style": "BLIND",
      "render": "BLIND_EXTENSION"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Open Diagonal Angle Cabinet": {
    "productName": "Tall Open Diagonal Angle Cabinet",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 4
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Open End Cabinet": {
    "productName": "Tall Open End Cabinet",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 4
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Open No Bottom": {
    "productName": "Tall Open No Bottom",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": false,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 4
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Open Pigeon Holes": {
    "productName": "Tall Open Pigeon Holes",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": false,
      "count": 0,
      "pigeonHoles": true
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {
      "pigeonHoles": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Opening with End Panels": {
    "productName": "Tall Opening with End Panels",
    "category": "PANEL",
    "accessory": {
      "type": "PANEL",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Tall Pullout Pantry": {
    "productName": "Tall Pullout Pantry",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 4
    },
    "corner": null,
    "special": {
      "pullout": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Return Filler": {
    "productName": "Tall Return Filler",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Tall Scribe Filler": {
    "productName": "Tall Scribe Filler",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Tall Scribe Filler With Cleats": {
    "productName": "Tall Scribe Filler With Cleats",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Tall Sliding Door Cabinet": {
    "productName": "Tall Sliding Door Cabinet",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim",
      "doorMechanism": "Sliding"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Split Corner Pantry Cabinet": {
    "productName": "Tall Split Corner Pantry Cabinet",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 4
    },
    "corner": {
      "style": "CORNER_PANTRY",
      "render": "CORNER_PANTRY"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Starter": {
    "productName": "Tall Starter",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 4
    },
    "corner": null,
    "special": {
      "starter": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Transition Angle Cabinet": {
    "productName": "Tall Transition Angle Cabinet",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 4
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 4
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Tall Winerack": {
    "productName": "Tall Winerack",
    "category": "TALL",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": false,
      "count": 0,
      "wineRack": true
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {
      "wineRack": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Toe Kick Base": {
    "productName": "Toe Kick Base",
    "category": "TOEKICK",
    "accessory": {
      "type": "TOEKICK",
      "thicknessMm": 16,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Toe Kick Base With Angled Ends": {
    "productName": "Toe Kick Base With Angled Ends",
    "category": "TOEKICK",
    "accessory": {
      "type": "TOEKICK",
      "thicknessMm": 16,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Toe Kick Platform": {
    "productName": "Toe Kick Platform",
    "category": "TOEKICK",
    "accessory": {
      "type": "TOEKICK",
      "thicknessMm": 16,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Transition Toe Kick Base": {
    "productName": "Transition Toe Kick Base",
    "category": "TOEKICK",
    "accessory": {
      "type": "TOEKICK",
      "thicknessMm": 16,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Under Panel": {
    "productName": "Under Panel",
    "category": "PANEL",
    "accessory": {
      "type": "PANEL",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Under Stair 1 Door": {
    "productName": "Under Stair 1 Door",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Under Stair 2 Door": {
    "productName": "Under Stair 2 Door",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 2,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Under Stair Vertical 2 Bay Cabinet": {
    "productName": "Under Stair Vertical 2 Bay Cabinet",
    "category": "BASE",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": false,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": true,
      "heightMm": 135,
      "setbackMm": 50,
      "kickboardThicknessMm": 16,
      "legs": true,
      "legsCount": 4
    },
    "shelves": {
      "adjustable": true,
      "count": 1
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 1
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": true,
      "thicknessMm": 20,
      "overhangFrontMm": 20,
      "overhangSideMm": 0
    }
  },
  "Upper 1 Door": {
    "productName": "Upper 1 Door",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper 1 Door Glass Door": {
    "productName": "Upper 1 Door Glass Door",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": true
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper 2 Door": {
    "productName": "Upper 2 Door",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 2,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper 2 Door Glass Door": {
    "productName": "Upper 2 Door Glass Door",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 2,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": true
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper 2 Door Microwave": {
    "productName": "Upper 2 Door Microwave",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "APPLIANCE_OPENING",
      "appliance": "MICROWAVE",
      "hasTopDrawer": false,
      "hasDoors": true,
      "doorCount": 2,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "appliance": "MICROWAVE"
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper 3 Door": {
    "productName": "Upper 3 Door",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 3,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Any Angle Cabinet": {
    "productName": "Upper Any Angle Cabinet",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 2
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Applied Back Panel": {
    "productName": "Upper Applied Back Panel",
    "category": "PANEL",
    "accessory": {
      "type": "PANEL",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Upper Applied Panel": {
    "productName": "Upper Applied Panel",
    "category": "PANEL",
    "accessory": {
      "type": "PANEL",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Upper Blind Corner": {
    "productName": "Upper Blind Corner",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 2
    },
    "corner": {
      "style": "BLIND",
      "render": "BLIND_EXTENSION"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Corner Diagonal Cabinet": {
    "productName": "Upper Corner Diagonal Cabinet",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 2
    },
    "corner": {
      "style": "DIAGONAL",
      "render": "DIAGONAL_FRONT_45"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Corner Filler With Cleats": {
    "productName": "Upper Corner Filler With Cleats",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Upper Corner Open Cabinet": {
    "productName": "Upper Corner Open Cabinet",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 2
    },
    "corner": {
      "style": "L_SHAPE",
      "render": "L_ARMS"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Corner Open Curved Cabinet": {
    "productName": "Upper Corner Open Curved Cabinet",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 2
    },
    "corner": {
      "style": "L_SHAPE",
      "render": "L_ARMS"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Corner Open Diagonal Cabinet": {
    "productName": "Upper Corner Open Diagonal Cabinet",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 2
    },
    "corner": {
      "style": "DIAGONAL",
      "render": "DIAGONAL_FRONT_45"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Diagonal Angle Cabinet": {
    "productName": "Upper Diagonal Angle Cabinet",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 2
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Folding Door Cabinet": {
    "productName": "Upper Folding Door Cabinet",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim",
      "doorMechanism": "Folding"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Horizontal Winerack": {
    "productName": "Upper Horizontal Winerack",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0,
      "wineRack": true
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {
      "wineRack": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Microwave Cabinet": {
    "productName": "Upper Microwave Cabinet",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "APPLIANCE_OPENING",
      "appliance": "MICROWAVE",
      "hasTopDrawer": false,
      "hasDoors": false,
      "doorCount": 0,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "appliance": "MICROWAVE"
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Open": {
    "productName": "Upper Open",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 2
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Open Blind Corner": {
    "productName": "Upper Open Blind Corner",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 2
    },
    "corner": {
      "style": "BLIND",
      "render": "BLIND_EXTENSION"
    },
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Open Diagonal Angle Cabinet": {
    "productName": "Upper Open Diagonal Angle Cabinet",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 2
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Open End Cabinet": {
    "productName": "Upper Open End Cabinet",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 2
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Open Pigeon Holes": {
    "productName": "Upper Open Pigeon Holes",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0,
      "pigeonHoles": true
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {
      "pigeonHoles": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Opening with End Panels": {
    "productName": "Upper Opening with End Panels",
    "category": "PANEL",
    "accessory": {
      "type": "PANEL",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Upper Rangehood Cabinet": {
    "productName": "Upper Rangehood Cabinet",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "APPLIANCE_OPENING",
      "appliance": "RANGEHOOD",
      "hasTopDrawer": false,
      "hasDoors": false,
      "doorCount": 0,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "appliance": "RANGEHOOD"
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Return Filler": {
    "productName": "Upper Return Filler",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Upper Scribe Filler": {
    "productName": "Upper Scribe Filler",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Upper Scribe Filler With Cleats": {
    "productName": "Upper Scribe Filler With Cleats",
    "category": "FILLER",
    "accessory": {
      "type": "FILLER",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Upper Sliding Door Cabinet": {
    "productName": "Upper Sliding Door Cabinet",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "DOORS",
      "doorCount": 1,
      "overlay": "FULL_OVERLAY",
      "revealGapMm": 2,
      "glassDoor": false
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim",
      "doorMechanism": "Sliding"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Sloped Top": {
    "productName": "Upper Sloped Top",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 2
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Starter": {
    "productName": "Upper Starter",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 2
    },
    "corner": null,
    "special": {
      "starter": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Transition Angle Cabinet": {
    "productName": "Upper Transition Angle Cabinet",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 2
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 2
    },
    "corner": null,
    "special": {},
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Undermount Rangehood Cabinet": {
    "productName": "Upper Undermount Rangehood Cabinet",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": true,
      "count": 0
    },
    "fronts": {
      "type": "APPLIANCE_OPENING",
      "appliance": "RANGEHOOD",
      "hasTopDrawer": false,
      "hasDoors": false,
      "doorCount": 0,
      "revealGapMm": 2
    },
    "corner": null,
    "special": {
      "appliance": "RANGEHOOD"
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Upper Winerack": {
    "productName": "Upper Winerack",
    "category": "UPPER",
    "carcass": {
      "gableThicknessMm": 18,
      "panelThicknessMm": 18,
      "backThicknessMm": 3,
      "backRecessMm": 18,
      "hasTopPanel": true,
      "hasBottomPanel": true,
      "hasBackPanel": true
    },
    "toeKick": {
      "enabled": false
    },
    "shelves": {
      "adjustable": false,
      "count": 0,
      "wineRack": true
    },
    "fronts": {
      "type": "OPEN",
      "shelfCount": 0
    },
    "corner": null,
    "special": {
      "wineRack": true
    },
    "hardwareDefaults": {
      "hingeBrand": "Blum",
      "hingeType": "Full Overlay Soft Close",
      "drawerSlideType": "Hafele Alto Slim",
      "drawerSystem": "Alto Slim"
    },
    "renderHints": {
      "doorStyle": "slab",
      "showHandles": true
    },
    "benchtop": {
      "enabled": false
    }
  },
  "Valance": {
    "productName": "Valance",
    "category": "TRIM",
    "accessory": {
      "type": "TRIM",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  },
  "Wall Rail": {
    "productName": "Wall Rail",
    "category": "TRIM",
    "accessory": {
      "type": "TRIM",
      "thicknessMm": 18,
      "render": "RECT_EXTRUSION"
    },
    "renderHints": {
      "showHandles": false
    }
  }
} as const;

    export function getConstructionRecipe(
      productName: string,
      map: Record<string, ConstructionRecipe> = MV_CONSTRUCTION_RECIPES_FULL
    ): ConstructionRecipe | null {
      return map[productName] ?? null;
    }
